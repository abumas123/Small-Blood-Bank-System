import sqlite3

global conn, cursor
conn = sqlite3.connect("pythontut.db")
cursor = conn.cursor()
cursor.execute(
    "CREATE TABLE IF NOT EXISTS `users` (user_id INTEGER NOT NULL PRIMARY KEY  AUTOINCREMENT, username TEXT, password TEXT)")
cursor.execute("SELECT * FROM `users` WHERE `username` = 'admin' AND `password` = 'admin'")
if cursor.fetchone() is None:
    cursor.execute("INSERT INTO `users` (username, password) VALUES('admin', 'admin')")
    conn.commit()