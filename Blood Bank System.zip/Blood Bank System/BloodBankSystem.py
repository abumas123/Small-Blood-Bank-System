
from tkinter import *
import random
import time;
from tkinter import StringVar
import sqlite3
from tkinter import ttk
from tkinter import messagebox

class StudentsProject:
    def __init__(self):
        self.root = Tk()
        self.root.geometry("1600x800+0+0")

        self.root.title("Blood Bank System")
        self.fr = Frame(self.root, width=1200, height=100, bg="powder blue", relief=SUNKEN).pack()



        lbl_title = Label(self.fr, text=" Blood Bank " ,font=('arial', 25, 'bold'),
                          fg="red", bd=10 ,anchor='w').pack()
        btnlogin = Button(self.fr, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 14, 'bold'),
                          text="Login Page", bd=10, command=self.Fun_win_login).pack()
        # =========================Database Students================

        self.db = sqlite3.connect("BloodBank.db")
        self.db.row_factory = sqlite3.Row
        self.db.execute("create table if not exists  donor(id integer primary key  autoincrement,"
                        "no integer,name text,age integer ,BloodGroup text ,Phone integer )")
        self.db.commit()
        # ========================End Database ======================

        self.win_donor= Toplevel()
        self.win_donor.withdraw()
        self.win_login = Toplevel()
        self.win_login.withdraw()
        self.win_add = Toplevel()
        self.win_add.withdraw()
        self.win_update = Toplevel()
        self.win_update.withdraw()
        self.win_updatePass = Toplevel()
        self.win_updatePass.withdraw()

        # =====================================Start login=========================

        self.win_login.title("  Login Page   ")
        self.win_donor.title("Blood Bank System")
        width = 1200
        height = 800
        self.screen_width = self.win_login.winfo_screenwidth()  # width of the screen
        self.screen_height = self.win_login.winfo_screenheight()  # height of the screen
        # calculate x and y coordinates for the Tk root window
        x = (self.screen_width / 2) - (width / 2)
        y = (self.screen_height / 2) - (height / 2)
        self.win_login.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.win_login.resizable(0, 0)
        # ==============================VARIABLES======================================
        self.USERNAME = StringVar()
        self.PASSWORD = StringVar()
        self.USERNAME.set('admin')
        # ==============================FRAMES=========================================
        Top = Frame(self.win_login, bd=2, relief=RIDGE)
        Top.pack(side=TOP, fill=X)
        Form = Frame(self.win_login, height=200)
        Form.pack(side=TOP, pady=20)

        # ==============================LABELS=========================================
        lbl_title = Label(Top, text="Blood Bank System", font=('arial', 15))
        lbl_title.pack(fill=X)
        lbl_username = Label(Form, text="Username:", font=('arial', 14), bd=15)
        lbl_username.grid(row=0, sticky="e")
        lbl_password = Label(Form, text="Password:", font=('arial', 14), bd=15)
        lbl_password.grid(row=1, sticky="e")
        self.lbl_text = Label(Form)
        self.lbl_text.grid(row=2, columnspan=2)

        # ==============================ENTRY WIDGETS==================================
        username = Entry(Form, textvariable=self.USERNAME, font=(14))
        username.grid(row=0, column=1)
        password = Entry(Form, textvariable=self.PASSWORD, show="*", font=(14))
        password.grid(row=1, column=1)

        # ==============================BUTTON WIDGETS=================================
        btn_login = Button(Form, text="Login", width=45, command=self.Fun_Login)
        btn_login.grid(pady=25, row=3, columnspan=2)


        #==============================ubdate password==================================


        self.f10 = Frame(self.win_updatePass, width=1200, height=20, bg="black", relief=SUNKEN)
        self.f10.grid(row=0, column=0)

        self.USERNAME1 = StringVar()
        self.PASSWORD1 = StringVar()
        self.PASSWORD2 = StringVar()


        username1 =Entry(self.f10, textvariable=self.USERNAME1, font=(14))
        username1.grid(row=0, column=1)
        password1 = Entry(self.f10, textvariable=self.PASSWORD1, show="*", font=(14))
        password1.grid(row=1, column=1)
        password2 = ttk.Entry(self.f10, textvariable=self.PASSWORD2, show="*", font=(14))
        password2.grid(row=2, column=1)

        btn_login1 = Button(self.f10, text="to change password ", width=45, command=self.Fun_Login1)
        btn_login1.grid(pady=25, row=3, columnspan=2)
        btn_lback = Button(self.f10, text="back", width=45, command=self.Back6)
        btn_lback.grid(pady=25, row=4, columnspan=2)






        # ============================begin of widgets Donors=============
        self.f1 = Frame(self.win_donor, width=1200, height=20, bg="powder blue", relief=SUNKEN)
        self.f1.grid(row=0, column=0)

        self.f2 = Frame(self.win_donor, width=1200, height=100, relief=SUNKEN)
        self.f2.grid(row=2, column=0)

        self.f3 = Frame(self.win_donor, width=1200, height=100, bg="powder blue", relief=SUNKEN)
        self.f3.grid(row=3, column=0)

        #===============add window============================================
        self.f4 = Frame(self.win_add, width=1200, height=20, bg="powder blue", relief=SUNKEN)
        self.f4.grid(row=0, column=0)

        self.f5 = Frame(self.win_add, width=1200, height=100, relief=SUNKEN)
        self.f5.grid(row=2, column=0)

        self.f6 = Frame(self.win_add, width=1200, height=100, bg="powder blue", relief=SUNKEN)
        self.f6.grid(row=3, column=0)

        # ===============update window============================================
        self.f7 = Frame(self.win_update, width=1200, height=20, bg="powder blue", relief=SUNKEN)
        self.f7.grid(row=0, column=0)

        self.f8 = Frame(self.win_update, width=1200, height=100, relief=SUNKEN)
        self.f8.grid(row=2, column=0)

        self.f9 = Frame(self.win_update, width=1200, height=100, bg="powder blue", relief=SUNKEN)
        self.f9.grid(row=3, column=0)

        self.localtime = time.asctime(time.localtime(time.time()))
        self.lbInfo = Label(self.f1, font=('arial', 50, 'bold'), text="Blood Bank System", fg="Steel Blue",
                            bd=10,
                            anchor='w')
        self.lbInfo.grid(row=0, column=0)
        self.lbInfo = Label(self.f1, font=('arial', 14, 'bold'), text=self.localtime, fg="Steel Blue", bd=10,
                            anchor='w')
        self.lbInfo.grid(row=1, column=0)

        self.no = StringVar()
        self.name = StringVar()
        self.age = StringVar()
        self.BloodGroup = StringVar()
        self.Phone = StringVar()


        # =============================== entry filds well not be used here =============================================

        '''
        self.lbNo = Label(self.f2, font=('arial', 10, 'bold'), text="Number", bd=10)
        self.lbNo.grid(row=0, column=0)
        self.EntryNo = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.no)
        self.EntryNo.grid(row=0, column=1, pady=1)
        self.EntryNo.focus()

        self.lbName = Label(self.f2, font=('arial', 10, 'bold'), text="Name", bd=10)
        self.lbName.grid(row=0, column=2)
        self.EntryName = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.name)
        self.EntryName.grid(row=0, column=3, pady=1)
        self.EntryName.focus()

        self.lbM1 = Label(self.f2, font=('arial', 10, 'bold'), text="Mark1", bd=10)
        self.lbM1.grid(row=1, column=0)
        self.EntryM1 = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.m1)
        self.EntryM1.grid(row=1, column=1, pady=1)
        self.EntryM1.focus()

        self.lbM2 = Label(self.f2, font=('arial', 10, 'bold'), text="Mark2", bd=10)
        self.lbM2.grid(row=2, column=0)
        self.EntryM2 = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.m2)
        self.EntryM2.grid(row=2, column=1, pady=1)
        self.EntryM2.focus()

        self.lbM3 = Label(self.f2, font=('arial', 10, 'bold'), text="Mark3", bd=10)
        self.lbM3.grid(row=3, column=0)
        self.EntryM3 = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.m3)
        self.EntryM3.grid(row=3, column=1, pady=1)
        self.EntryM3.focus()

        self.lbSum = Label(self.f2, font=('arial', 10, 'bold'), text="Total", bd=10)
        self.lbSum.grid(row=4, column=0)
        self.EntrySum = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.sum, state="readonly")
        self.EntrySum.grid(row=4, column=1, pady=1)

        self.lbAve = Label(self.f2, font=('arial', 10, 'bold'), text="Average", bd=10)
        self.lbAve.grid(row=5, column=0)
        self.EntryAve = ttk.Entry(self.f2, width=20, font=('Arial', 10), textvariable=self.ave, state="readonly")
        self.EntryAve.grid(row=5, column=1, pady=1)

        '''
        # ===============================================================================

        self.btnShow = Button(self.f2, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                              text="Show", bd=10, command=self.FunShow).grid(row=1, column=3)

        self.btnAdd = Button(self.f2, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                             text="Add", bd=10, command=self.AddWindow).grid(row=2, column=3)

        self.btnDel = Button(self.f2, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                             text="Delete", bd=10, command=self.UpdateWindow).grid(row=3, column=3)

        self.btnUpdate = Button(self.f2, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                                text="Update", bd=10, command=self.UpdateWindow).grid(row=4, column=3)

        btn_back = Button(self.f2, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                          text="Back", bd=10, command=self.Back).grid(row=5, column=5)
        # ============================================================================

        self.tv = ttk.Treeview(self.f3)
        self.tv.grid(row=0, column=0)

        self.tv.heading('#0', text='ID')

        self.tv.configure(column=('#Number', '#Name', '#age', '#BloodGroup', '#Phone'))
        self.tv.column('#0', width=80, anchor='center')
        self.tv.column('#Number', width=80, anchor='center')
        self.tv.column('#Name', width=80, anchor='center')
        self.tv.column('#age', width=80, anchor='center')
        self.tv.column('#BloodGroup', width=80, anchor='center')
        self.tv.column('#Phone', width=80, anchor='center')


        self.tv.heading('#Number', text='Number')
        self.tv.heading('#Name', text='Name')
        self.tv.heading('#age', text='Age')
        self.tv.heading('#BloodGroup', text='BloodGroup')
        self.tv.heading('#Phone', text='Phone')



        #===============add window============================================

        self.lbInfo = Label(self.f4, font=('arial', 30, 'bold'), text="Insert And Delete Donors Records", fg="red",
                            bd=10,
                            anchor='w')
        self.lbInfo.grid(row=0, column=0)







        self.lbNo = Label(self.f5, font=('arial', 10, 'bold'), text="Number", bd=10)
        self.lbNo.grid(row=0, column=0)
        self.EntryNo = ttk.Entry(self.f5, width=20, font=('Arial', 10), textvariable=self.no)
        self.EntryNo.grid(row=0, column=1, pady=1)
        self.EntryNo.focus()

        self.lbName = Label(self.f5, font=('arial', 10, 'bold'), text="Name", bd=10)
        self.lbName.grid(row=0, column=2)
        self.EntryName = ttk.Entry(self.f5, width=20, font=('Arial', 10), textvariable=self.name)
        self.EntryName.grid(row=0, column=3, pady=1)
        self.EntryName.focus()

        self.lbM1 = Label(self.f5, font=('arial', 10, 'bold'), text="Age", bd=10)
        self.lbM1.grid(row=1, column=0)
        self.EntryM1 = ttk.Entry(self.f5, width=20, font=('Arial', 10), textvariable=self.age)
        self.EntryM1.grid(row=1, column=1, pady=1)
        self.EntryM1.focus()

        self.lbM2 = Label(self.f5, font=('arial', 10, 'bold'), text="BloodGroup", bd=10)
        self.lbM2.grid(row=2, column=0)
        self.EntryM2 = ttk.Entry(self.f5, width=20, font=('Arial', 10), textvariable=self.BloodGroup)
        self.EntryM2.grid(row=2, column=1, pady=1)
        self.EntryM2.focus()

        self.lbM3 = Label(self.f5, font=('arial', 10, 'bold'), text="Phone", bd=10)
        self.lbM3.grid(row=3, column=0)
        self.EntryM3 = ttk.Entry(self.f5, width=20, font=('Arial', 10), textvariable=self.Phone)
        self.EntryM3.grid(row=3, column=1, pady=1)
        self.EntryM3.focus()








        self.btnAdd = Button(self.f5, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                             text="Add", bd=10, command=self.FunAdd).grid(row=2, column=3)

        self.btnShow1 = Button(self.f5, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                              text="Show", bd=10, command=self.FunShow1).grid(row=1, column=3)

        self.btnClear1 = Button(self.f5, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                               text="Clear", bd=10, command=self.FunClear).grid(row=5, column=3)

        Button(self.f5, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                          text="Back", bd=10, command=self.Back2).grid(row=5, column=5)





        self.tv1 = ttk.Treeview(self.f6)
        self.tv1.grid(row=0, column=0)

        self.tv1.heading('#0', text='ID')

        self.tv1.configure(column=('#Number', '#Name', '#age', '#BloodGroup', '#Phone'))
        self.tv1.column('#0', width=80, anchor='center')
        self.tv1.column('#Number', width=80, anchor='center')
        self.tv1.column('#Name', width=80, anchor='center')
        self.tv1.column('#age', width=80, anchor='center')
        self.tv1.column('#BloodGroup', width=80, anchor='center')
        self.tv1.column('#Phone', width=80, anchor='center')


        self.tv1.heading('#Number', text='Number')
        self.tv1.heading('#Name', text='Name')
        self.tv1.heading('#age', text='Age')
        self.tv1.heading('#BloodGroup', text='BloodGroup')
        self.tv1.heading('#Phone', text='Phone')

        # ===============update window============================================

        self.lbInfo = Label(self.f7, font=('arial', 50, 'bold'), text="Update Donors Records", fg="red",
                            bd=10,
                            anchor='w')
        self.lbInfo.grid(row=0, column=0)

        self.lbNo = Label(self.f8, font=('arial', 10, 'bold'), text="Number", bd=10)
        self.lbNo.grid(row=0, column=0)
        self.EntryNo = ttk.Entry(self.f8, width=20, font=('Arial', 10), textvariable=self.no)
        self.EntryNo.grid(row=0, column=1, pady=1)
        self.EntryNo.focus()

        self.lbName = Label(self.f8, font=('arial', 10, 'bold'), text="Name", bd=10)
        self.lbName.grid(row=0, column=2)
        self.EntryName = ttk.Entry(self.f8, width=20, font=('Arial', 10), textvariable=self.name)
        self.EntryName.grid(row=0, column=3, pady=1)
        self.EntryName.focus()

        self.lbM1 = Label(self.f8, font=('arial', 10, 'bold'), text="Age", bd=10)
        self.lbM1.grid(row=1, column=0)
        self.EntryM1 = ttk.Entry(self.f8, width=20, font=('Arial', 10), textvariable=self.age)
        self.EntryM1.grid(row=1, column=1, pady=1)
        self.EntryM1.focus()

        self.lbM2 = Label(self.f8, font=('arial', 10, 'bold'), text="BloodGroup", bd=10)
        self.lbM2.grid(row=2, column=0)
        self.EntryM2 = ttk.Entry(self.f8, width=20, font=('Arial', 10), textvariable=self.BloodGroup)
        self.EntryM2.grid(row=2, column=1, pady=1)
        self.EntryM2.focus()

        self.lbM3 = Label(self.f8, font=('arial', 10, 'bold'), text="Phone", bd=10)
        self.lbM3.grid(row=3, column=0)
        self.EntryM3 = ttk.Entry(self.f8, width=20, font=('Arial', 10), textvariable=self.Phone)
        self.EntryM3.grid(row=3, column=1, pady=1)
        self.EntryM3.focus()

        self.btnUpdate2 = Button(self.f8, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                                text="Update", bd=10, command=self.FunUpdate).grid(row=4, column=3)

        self.btnShow2 = Button(self.f8, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                              text="Show", bd=10, command=self.FunShow2).grid(row=1, column=3)
        self.btnDel1 = Button(self.f8, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                             text="Delete", bd=10, command=self.FunDel).grid(row=3, column=3)

        self.btnClear2 = Button(self.f8, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                                text="Clear", bd=10, command=self.FunClear).grid(row=5, column=3)

        btn_back2 = Button(self.f8, height=1, width=10, padx=2, pady=2, fg='black', font=('arial', 10, 'bold'),
                          text="Back", bd=10, command=self.Back3).grid(row=5, column=5)

        self.tv2 = ttk.Treeview(self.f9)
        self.tv2.grid(row=0, column=0)

        self.tv2.heading('#0', text='ID')

        self.tv2.configure(column=('#Number', '#Name', '#age', '#BloodGroup', '#Phone'))
        self.tv2.column('#0', width=80, anchor='center')
        self.tv2.column('#Number', width=80, anchor='center')
        self.tv2.column('#Name', width=80, anchor='center')
        self.tv2.column('#age', width=80, anchor='center')
        self.tv2.column('#BloodGroup', width=80, anchor='center')
        self.tv2.column('#Phone', width=80, anchor='center')

        self.tv2.heading('#Number', text='Number')
        self.tv2.heading('#Name', text='Name')
        self.tv2.heading('#age', text='Age')
        self.tv2.heading('#BloodGroup', text='BloodGroup')
        self.tv2.heading('#Phone', text='Phone')






        # self.tv.bind("<<TreeviewSelect>>", self.on_tree_select2)
        self.binding()

        # ======================End widgets Donors=========================




        self.root.mainloop()
        # ======================begin of login Funcations ===================

    def Fun_win_login(self):
        print("hhhhhhh")
        self.root.withdraw()
        # self.root.resizable(0,0)
        self.win_login.deiconify()

    def Fun_Login(self, event=None):
        self.Database()
        if self.USERNAME.get() == "" or self.PASSWORD.get() == "":
            self.lbl_text.config(text="Please complete the required field!", fg="red")
        else:
            cursor.execute("SELECT * FROM `users` WHERE `username` = ? AND `password` = ?",
                           (self.USERNAME.get(), self.PASSWORD.get()))
            if cursor.fetchone() is not None:
                self.HomeWindow()
                self.USERNAME.set("")
                self.PASSWORD.set("")
                self.lbl_text.config(text="")
            else:
                self.lbl_text.config(text="Invalid username or password", fg="red")
                self.USERNAME.set("")
                self.PASSWORD.set("")


    def Fun_Login1(self, event=None):

        #self.Database()

        pass1 = self.PASSWORD2.get()
        use1 = 'admin'
        if self.USERNAME1.get() == "" or self.PASSWORD1.get() == "":
           self.lbl_text.config(text="Please complete the required field!", fg="red")
        #else:
         #  cursor.execute("SELECT * FROM `users` WHERE `username` = ? AND `password` = ?",
          #                 (self.USERNAME1.get(), self.PASSWORD1.get()))
       # if cursor.fetchone() is not None:

        self.db.execute('UPDATE users SET password =? WHERE username =? ',(pass1 , use1))
        self.db.commit()
        messagebox.showinfo(title="Add info", message='Data is Updated')
        self.USERNAME1.set("")
        self.PASSWORD1.set("")
        self.PASSWORD2.set("")
        self.lbl_text.config(text="")

        #else:
           # self.lbl_text.config(text="Invalid username or password", fg="red")
            #self.USERNAME1.set("")
            #self.PASSWORD1.set("")
        #cursor1.close()
        #conn1.close()
        # ==============================METHODS========================================

    def Database(self):
        global conn, cursor
        conn = sqlite3.connect("pythontut.db")
        cursor = conn.cursor()
        cursor.execute(
            "CREATE TABLE IF NOT EXISTS `users` (user_id INTEGER NOT NULL PRIMARY KEY  AUTOINCREMENT, username TEXT, password TEXT)")
        cursor.execute("SELECT * FROM `users` WHERE `username` = 'admin' AND `password` = 'admin'")
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO `users` (username, password) VALUES('admin', 'admin')")



        cursor.execute("SELECT * FROM `users` WHERE `username` = 'aa' AND `password` = '11'")
        if cursor.fetchone() is None:
            cursor.execute("INSERT INTO `users` (username, password) VALUES('aa', '11')")


            conn.commit()

    def HomeWindow(self):
        messagebox.showinfo(title="Login!", message="Successfully Login!")
        self.page2()

        width = 1200
        height = 800
        x = (self.screen_width / 2) - (width / 2)
        y = (self.screen_height / 2) - (height / 2)

        self.root.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.root.resizable(0, 0)
    def page2(self):
        # seems to just remove the window from the screen, after which the window has a state of "withdrawn"
        self.win_login.withdraw()
        self.win_donor.deiconify()

    def Back(self):
        self.win_donor.withdraw()
        self.root.deiconify()
        self.root.resizable(0, 0)

    def binding(self):
        self.tv2.bind("<<TreeviewSelect>>", self.on_tree_select2)

#=========update password=============
    def updatePass(self):

        self.page6()

        width = 1200
        height = 800
        x = (self.screen_width / 2) - (width / 2)
        y = (self.screen_height / 2) - (height / 2)

        self.root.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.root.resizable(0, 0)

    def page6(self):
            # seems to just remove the window from the screen, after which the window has a state of "withdrawn"
        self.win_login.withdraw()
        self.win_updatePass.deiconify()

    def Back6(self):
        self.win_updatePass.withdraw()
        self.win_login.deiconify()
        self.root.resizable(0, 0)
#========Add window===================
    def AddWindow(self):

        self.page3()

        width = 1200
        height = 800
        x = (self.screen_width / 2) - (width / 2)
        y = (self.screen_height / 2) - (height / 2)

        self.root.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.root.resizable(0, 0)

    def page3(self):
            # seems to just remove the window from the screen, after which the window has a state of "withdrawn"
        self.win_donor.withdraw()
        self.win_add.deiconify()

    def Back2(self):
        self.win_add.withdraw()
        self.win_donor.deiconify()
        self.root.resizable(0, 0)

    # ========UPdatewindow===================

    def UpdateWindow(self):
        self.page4()

        width = 1200
        height = 800
        x = (self.screen_width / 2) - (width / 2)
        y = (self.screen_height / 2) - (height / 2)

        self.root.geometry("%dx%d+%d+%d" % (width, height, x, y))
        self.root.resizable(0, 0)

    def page4(self):
            # seems to just remove the window from the screen, after which the window has a state of "withdrawn"
        self.win_donor.withdraw()
        self.win_update.deiconify()

    def Back3(self):
        self.win_update.withdraw()
        self.win_donor.deiconify()
        self.root.resizable(0, 0)
        # ===============================================================================


    def FunAdd(self):

        no = self.EntryNo.get()
        name = self.EntryName.get()
        age = self.EntryM1.get()
        bloodgroup = self.EntryM2.get()
        phone= self.EntryM3.get()
        if \
                (self.EntryNo.get() == "" or self.EntryName.get() == "" or self.EntryM1.get() == "" or self.EntryM2.get() == "" or self.EntryM3.get() == ""):
            messagebox.showinfo(title="Add info", message='Please Insert Data !!!!!')
        else:


            self.db.execute("insert into donor(no,name, age,BloodGroup,Phone) values (?, ? , ? , ? , ?)",
                            (no, name, age, bloodgroup, phone))
            self.db.commit()
            messagebox.showinfo(title="Add info", message='added')
            self.FunShow()
            self.FunClear()
            # ==================tree.delete(*tree.get_children())=============================================================

    def FunClear(self):
        self.EntryName.delete(0, 'end')
        self.EntryNo.delete(0, 'end')
        self.EntryM1.delete(0, 'end')
        self.EntryM2.delete(0, 'end')
        self.EntryM3.delete(0, 'end')


    def FunShow(self):

        # x = self.tv.get_children()        for item in x:            self.tv.delete(item)

        self.tv.delete(*self.tv.get_children())

        cursor = self.db.execute("select * from donor")
        for row in cursor:
            self.tv.insert('', 'end', '{}'.format(row['id']), text=row['id'])
            self.tv.set('{}'.format(row['id']), '#Number', row['no'])  # x=id  y=#number  data= from row[no]
            self.tv.set('{}'.format(row['id']), '#Name', row['name'])
            self.tv.set('{}'.format(row['id']), '#age', row['age'])
            self.tv.set('{}'.format(row['id']), '#BloodGroup', row['BloodGroup'])
            self.tv.set('{}'.format(row['id']), '#Phone', row['Phone'])


        item_count = len(self.tv.get_children())
        print('item_count=', item_count)

    def FunShow1(self):

            # x = self.tv.get_children()        for item in x:            self.tv.delete(item)

        self.tv1.delete(*self.tv1.get_children())

        cursor = self.db.execute("select * from donor")
        for row in cursor:
                self.tv1.insert('', 'end', '{}'.format(row['id']), text=row['id'])
                self.tv1.set('{}'.format(row['id']), '#Number', row['no'])  # x=id  y=#number  data= from row[no]
                self.tv1.set('{}'.format(row['id']), '#Name', row['name'])
                self.tv1.set('{}'.format(row['id']), '#age', row['age'])
                self.tv1.set('{}'.format(row['id']), '#BloodGroup', row['BloodGroup'])
                self.tv1.set('{}'.format(row['id']), '#Phone', row['Phone'])

        item_count = len(self.tv1.get_children())
        print('item_count=', item_count)



    def FunShow2(self):

                # x = self.tv.get_children()        for item in x:            self.tv.delete(item)

        self.tv2.delete(*self.tv2.get_children())

        cursor = self.db.execute("select * from donor")
        for row in cursor:
                    self.tv2.insert('', 'end', '{}'.format(row['id']), text=row['id'])
                    self.tv2.set('{}'.format(row['id']), '#Number', row['no'])  # x=id  y=#number  data= from row[no]
                    self.tv2.set('{}'.format(row['id']), '#Name', row['name'])
                    self.tv2.set('{}'.format(row['id']), '#age', row['age'])
                    self.tv2.set('{}'.format(row['id']), '#BloodGroup', row['BloodGroup'])
                    self.tv2.set('{}'.format(row['id']), '#Phone', row['Phone'])

        item_count = len(self.tv2.get_children())
        print('item_count=', item_count)





        # ===============================================================================

    def on_tree_select2(self, event):

        selected_item = self.tv2.selection()[0]
        cursor = self.db.execute("select * from donor where id=?", (selected_item,))

        for row in cursor:
            self.no.set(str(row['no']))
            self.name.set(str(row['name']))
            self.age.set(str(row['age']))
            self.BloodGroup.set(str(row['BloodGroup']))
            self.Phone.set(str(row['Phone']))


            # ======================================================

    def FunUpdate(self):

        selected_item = self.tv2.selection()[0]
        if (
                self.EntryName.get() == ""
             or self.EntryNo.get() == ""
             or self.EntryM1.get() == ""
             or self.EntryM2.get() == ""
             or self.EntryM3.get() == ""):
            messagebox.showinfo(title="Add info", message='Please Insert Data !!!!!')
        else:
            no = self.EntryNo.get()
            name = self.EntryName.get()
            age = self.EntryM1.get()
            BloodGroup = self.EntryM2.get()
            Phone = self.EntryM3.get()


            selected_item = self.tv2.selection()[0]

            id = selected_item
            print("id=====", selected_item)

            self.db.execute('UPDATE donor SET no=? ,name=?, age=?, BloodGroup=?, Phone=? WHERE id=?',
                            (no, name, age, BloodGroup,Phone,id))
            self.db.commit()
            messagebox.showinfo(title="Add info", message='Data is Updated')
            self.FunShow2()
            self.FunClear()

            # ===============================================================================

    def FunDel(self):

        conn = sqlite3.connect("BloodBank.db")
        self.db.row_factory = sqlite3.Row
        selected_item = self.tv2.selection()[0]
        print('selected_item', selected_item)  # it prints the selected row id
        cur = conn.cursor()
        cur.execute("DELETE FROM donor WHERE id=?", (selected_item,))
        conn.commit()

        self.tv.delete(selected_item)
        messagebox.showinfo(title="Add info", message='Record is deleted')
        self.FunShow2()
        self.FunClear()

        # =========================================


def main():
    StudentsProject()


# ==============================INITIALIATION==================================
if __name__ == '__main__':
    main()

